package com.example.benu;

public class DataModel {

    String name;
    String version;
    int id_;
    int image;

    public DataModel(String name, int id_) {
        this.name = name;
        this.id_ = id_;
    }
    public String getName() {
        return name;
    }
    public int getId() {
        return id_;
    }
}