package com.example.benu;

public class MyData {

    static String[] nameArray = {"Jane", "Andrew", "John","sarah","rakesh"};


   /* static Integer[] drawableArray = {R.drawable.cupcake, R.drawable.donut, R.drawable.eclair,
            R.drawable.froyo, R.drawable.gingerbread, R.drawable.honeycomb, R.drawable.ics,
            R.drawable.jellybean, R.drawable.kitkat, R.drawable.lollipop,R.drawable.marsh};*/

    static Integer[] id_ = {0, 1, 2,3,4};
}